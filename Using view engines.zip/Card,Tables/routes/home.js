var express = require('express');
var router = express.Router();
var app=express()
app.use(express.static(__dirname+'/public'))
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('home', { title: 'Express' });
});
router.get('/cards',(req,res)=>{
 
  const cards=[
    
      { name: 'Mean', imageUrl: '/images/download.jpeg' },
      { name: 'mern', imageUrl: '/images/download.png' },
      { name: 'python', imageUrl: '/images/download (1).jpeg' },
      { name: 'cyber security', imageUrl: 'images/download (2).jpeg' },
    
  ]
  res.render('cards',{cards})
})
router.get('/list',(req,res)=>{
 
  const lists=[
     {domain:"mean stack"},
     {domain:"flutter"},
     {domain:"python"},
     {domain:"data science"},
     {domain:"mern stack"}
    
  ]
  res.render('list',{lists})
})
router.get('/table',(req,res)=>{
 
  const tables=[
     {id:1 ,name:"binu",week:"3",domain:"mern stack"},
     {id:2 ,name:"susin",week:"4",domain:"mean stack"},
     {id:3 ,name:"jebin",week:"3",domain:"mern stack"},
     {id:4 ,name:"nibeen",week:"4",domain:"mean stack"},
     {id:5 ,name:"abhiyan",week:"3",domain:"game developemnt"}
    
  ]
  res.render('table',{tables})
})
module.exports = router;
